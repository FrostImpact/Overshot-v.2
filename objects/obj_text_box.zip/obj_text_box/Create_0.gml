text_pages = [];
page_index = 0;
char_index = 0;
text_color = c_black;
text_speed = 0.5;
pause_game = false;
auto_close_timer = -1;
margin = 16;