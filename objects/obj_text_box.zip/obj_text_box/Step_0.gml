if (page_index < array_length(text_pages)) {
    var _target_length = string_length(text_pages[page_index]);
    
    if (char_index < _target_length) {
        char_index += text_speed;
    } else if (auto_close_timer > 0) {
        auto_close_timer--;
        if (auto_close_timer <= 0) {
            page_index++;
            char_index = 0;
            if (page_index >= array_length(text_pages)) {
                if (pause_game) game_state_resume();
                instance_destroy();
            }
        }
    } else if (mouse_check_button_pressed(mb_left) || keyboard_check_pressed(vk_space)) {
        page_index++;
        char_index = 0;
        if (page_index >= array_length(text_pages)) {
            if (pause_game) game_state_resume();
            instance_destroy();
        }
    }
}